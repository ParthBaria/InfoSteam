import React from 'react'

function Auth() {
  return (
    <div>need to build</div>
  )
}

export default Auth