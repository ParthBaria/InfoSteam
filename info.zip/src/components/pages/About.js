import React from 'react'
import Detail from '../Fav/Detail'
import Nav from '../Nav'

function About() {
    return (
        <>
            <Nav />
            <Detail />
        </>
    )
}

export default About