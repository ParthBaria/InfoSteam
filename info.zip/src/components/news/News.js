import React from 'react'
import NewsList from './NewsList'
import useHttp from '../hook/http';
import "./News.css"
import LoadingIndicator from '../UI/LoadingIndicator'
function News(props) {
    const { isLoading, error } = useHttp();

    return (
        <><main className="main_container">
            {isLoading && <LoadingIndicator />}
            {!isLoading && <NewsList articles={props.news} />}
        </main>
        </>
    )
}

export default News