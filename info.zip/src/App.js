import './App.css';
import { Link, Route, Routes } from 'react-router';
import NewsPage from './components/pages/NewsPage';
import Favorites from './components/pages/Favorites';
import About from './components/pages/About';

function App() {
  return (

    <Routes>
      <Route path='/' element={<NewsPage />} />
      <Route path='favorites' element={<Favorites />} />
      <Route path='about' element={<About />} />
    </Routes>


  );
}

export default App;
